#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <mutex>

class Log {
public:
    enum class Level { INFO, WARNING, Error };

    static void Initialize(Level level = Level::INFO, const std::string& filename = "log.txt");
    static void SetLevel(Level level);
    static void LogMessage(Level level, const std::string& message);
    static void Shutdown();

private:
    static Level currentLevel;
    static std::ofstream logFile;
    static std::mutex logMutex;

    static const char* LevelToString(Level level);
};
