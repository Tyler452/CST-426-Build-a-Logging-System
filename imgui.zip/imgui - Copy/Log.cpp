#include "Log.h"
#include <Windows.h>  // For OutputDebugStringA on Windows

Log::Level Log::currentLevel = Log::Level::INFO;
std::ofstream Log::logFile;
std::mutex Log::logMutex;

void Log::Initialize(Level level, const std::string& filename) {
    std::lock_guard<std::mutex> guard(logMutex);
    currentLevel = level;
    logFile.open(filename, std::ios::out | std::ios::trunc);
    if (logFile.is_open()) {
        LogMessage(Level::INFO, "Logging Initialized");
    }
}

void Log::SetLevel(Level level) {
    std::lock_guard<std::mutex> guard(logMutex);
    currentLevel = level;
}

void Log::LogMessage(Level level, const std::string& message) {
    std::lock_guard<std::mutex> guard(logMutex);
    if (level < currentLevel) return;

    std::string logLine = std::string("[") + LevelToString(level) + "] " + message + "\n";

    // Console / Debug output
#ifdef _WIN32
    OutputDebugStringA(logLine.c_str());
#endif
    std::cout << logLine;

    // File output
    if (logFile.is_open()) {
        logFile << logLine;
        logFile.flush();
    }
}

void Log::Shutdown() {
    std::lock_guard<std::mutex> guard(logMutex);
    if (logFile.is_open()) {
        logFile.close();
    }
}

const char* Log::LevelToString(Level level) {
    switch (level) {
        case Level::INFO: return "INFO";
        case Level::WARNING: return "WARNING";
        case Level::Error: return "ERROR";
    }
    return "UNKNOWN";
}
